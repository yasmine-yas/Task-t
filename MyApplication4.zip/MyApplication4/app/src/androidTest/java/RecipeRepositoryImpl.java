public class RecipeRepositoryImpl implements RecipeRepository {
    private List<Recipe> recipes = new ArrayList<>();


}