public class RecipeUseCase {
    private RecipeRepository repository;

    public RecipeUseCase(RecipeRepository repository) {
        this.repository = repository;
    }

    public List<Recipe> getRecipes() {
        return repository.getRecipes();
    }

    public void toggleFavoriteStatus(Recipe recipe) {
        recipe.setFavorite(!recipe.isFavorite());
        repository.updateRecipe(recipe);
    }
}
