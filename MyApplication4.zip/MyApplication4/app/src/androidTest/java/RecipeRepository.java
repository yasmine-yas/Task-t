public interface RecipeRepository {
    List<Recipe> getRecipes();
    void updateRecipe(Recipe recipe);
}
